import React, { useState, useEffect } from "react";
import DataTable from "react-data-table-component";
import Modal1 from "../../components/Modal1";
import BonusPopup from "../../components/BounsPopup";

const Main = () => {
  const [open, setOpen] = useState(false);
  const tableData = [
    {
      userAddress: "000...X11",
      userLink: "000...X21",
      invest: "100$",
      earn: "500$",
      bones: "1000$",
    },
    {
      userAddress: "000...X12",
      userLink: "000...X22",
      invest: "100$",
      earn: "500$",
      bones: "1000$",
    },
    {
      userAddress: "000...X13",
      userLink: "000...X23",
      invest: "100$",
      earn: "500$",
      bones: "1000$",
    },
    {
      userAddress: "000...X14",
      userLink: "000...X24",
      invest: "100$",
      earn: "500$",
      bones: "1000$",
    },
    {
      userAddress: "000...X15",
      userLink: "000...X25",
      invest: "100$",
      earn: "500$",
      bones: "1000$",
    },
    {
      userAddress: "000...X16",
      userLink: "000...X26",
      invest: "100$",
      earn: "500$",
      bones: "1000$",
    },
    {
      userAddress: "000...X17",
      userLink: "000...X27",
      invest: "100$",
      earn: "500$",
      bones: "1000$",
    },
    {
      userAddress: "000...X18",
      userLink: "000...X28",
      invest: "100$",
      earn: "500$",
      bones: "1000$",
    },
    {
      userAddress: "000...X19",
      userLink: "000...X29",
      invest: "100$",
      earn: "500$",
      bones: "1000$",
    },
    {
      userAddress: "000...X10",
      userLink: "000...X30",
      invest: "100$",
      earn: "500$",
      bones: "1000$",
    },
    {
      userAddress: "000...X11",
      userLink: "000...X31",
      invest: "100$",
      earn: "500$",
      bones: "1000$",
    },
    {
      userAddress: "000...X12",
      userLink: "000...X32",
      invest: "100$",
      earn: "500$",
      bones: "1000$",
    },
  ];
  const renderColumns = () => {
    return [
      {
        name: "User Address",
        sortable: true,
        grow: 1,
        selector: (row) => row?.userAddress,
      },

      {
        name: "User Link",
        sortable: true,
        grow: 1,
        selector: (row) => row?.userLink,
      },
      {
        name: "Total Invest",
        sortable: true,
        grow: 1,
        selector: (row) => row?.invest,
      },
      {
        name: "Total Earn",
        sortable: true,
        grow: 1,
        selector: (row) => row?.earn,
      },
      {
        name: "Total Bonus",
        sortable: true,
        grow: 1,
        selector: (row) => row?.bones,
      },
      {
        name: "Status",
        sortable: true,
        cell: (row) => (
          <div>
            <div
              className="button btn rounded-lg"
              onClick={(e) => setOpen(true)}
            >
              Send Bonus
            </div>
          </div>
        ),
      },
    ];
  };
  return (
    <div className="home-page flex flex-col">
      <div className="wrap wrapWidth">
        <div className="info-wrapper">
          <div className="info-card flex flex-col items-center">
            <div className="icons flex items-center justify-center relative">
              <img src="./images/ellips.png" className="ellips" />
              <img src="./images/icon4.svg" className="icon absolute" />
            </div>
            <div className="card-name flex items-center justify-center flex-col">
              <div className="name">Total Earnings</div>
              <div className="amount">$0</div>
            </div>
          </div>
          <div className="info-card flex flex-col items-center">
            <div className="icons flex items-center justify-center relative">
              <img src="./images/ellips.png" className="ellips" />
              <img src="./images/icon5.svg" className="icon absolute" />
            </div>
            <div className="card-name flex items-center justify-center flex-col">
              <div className="name">Total Balance</div>
              <div className="amount">$0</div>
            </div>
          </div>
          <div className="info-card flex flex-col items-center">
            <div className="icons flex items-center justify-center relative">
              <img src="./images/ellips.png" className="ellips" />
              <img src="./images/icon6.svg" className="icon absolute" />
            </div>
            <div className="card-name flex items-center justify-center flex-col">
              <div className="name">Total invest</div>
              <div className="amount">$0</div>
            </div>
          </div>
          <div className="info-card flex flex-col items-center">
            <div className="icons flex items-center justify-center relative">
              <img src="./images/ellips.png" className="ellips" />
              <img src="./images/icon6.svg" className="icon absolute" />
            </div>
            <div className="card-name flex items-center justify-center flex-col">
              <div className="name">Total Withdraw</div>
              <div className="amount">$0</div>
            </div>
          </div>
          <div className="info-card flex flex-col items-center">
            <div className="icons flex items-center justify-center relative">
              <img src="./images/ellips.png" className="ellips" />
              <img src="./images/icon6.svg" className="icon absolute" />
            </div>
            <div className="card-name flex items-center justify-center flex-col">
              <div className="name">Total Withdraw</div>
              <div className="amount">$0</div>
            </div>
          </div>
          <div className="info-card flex flex-col items-center">
            <div className="icons flex items-center justify-center relative">
              <img src="./images/ellips.png" className="ellips" />
              <img src="./images/icon6.svg" className="icon absolute" />
            </div>
            <div className="card-name flex items-center justify-center flex-col">
              <div className="name">Total Withdraw</div>
              <div className="amount">$0</div>
            </div>
          </div>
        </div>
        <div className="plan-section flex flex-col">
          <div className="Withdraw-box flex items-center">
            <input
              type="text"
              className="txt cleanbtn w-full"
              placeholder="Withdraw Amount"
            />
            <button className="btn button">Withdraw</button>
          </div>
          <div className="tbl flex flex-col">
            <DataTable
              columns={renderColumns()}
              data={tableData}
              responsive={true}
              pagination={true}
            />
          </div>
        </div>
      </div>
      <Modal1 open={open} onClose={() => setOpen(false)}>
        <BonusPopup setOpen={setOpen} />
      </Modal1>
    </div>
  );
};

export default Main;
