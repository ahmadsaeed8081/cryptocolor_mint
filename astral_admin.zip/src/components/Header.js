import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

import Modal1 from "./Modal1";
import ConnectWallet from "../components/ConnectWallet";

const Header = () => {
  const [openWallet, setOpenWallet] = useState(false);
  return (
    <div className="header-camp flex">
      <div className="wrapWidth wrap flex aic">
        <div className="left flex aic">
          <Link to="/">
            <img src="./images/logo.svg" className="logo-img" />
          </Link>
        </div>
        <div className="right flex justify-end items-center">
          <div className="action flex items-center justify-center">
            <button
              className="btn-connect button"
              onClick={(e) => setOpenWallet(true)}
            >
              Connect Wallet
            </button>
          </div>
        </div>
      </div>
      <Modal1 open={openWallet} onClose={() => setOpenWallet(false)}>
        <ConnectWallet setOpenWallet={setOpenWallet} />
      </Modal1>
    </div>
  );
};

export default Header;
