import React from "react";
import { CloseIcon } from "../../assets";

const BonusPopup = ({ setOpen }) => {
  return (
    <div className="bonus-popup flex items-center flex-col">
      <div className="hdr flex items-center justify-end">
        <div
          className="close-icon flex items-center justify-center"
          onClick={(e) => setOpen(false)}
        >
          <CloseIcon />
        </div>
      </div>
      <div className="popup-wrap flex flex-col">
        <input type="text" placeholder="Enter Bonus Amount" className="txt" />
        <div className="btn button">Send</div>
      </div>
    </div>
  );
};

export default BonusPopup;
